package com.aircon;

public class aircon {

	private String brand;
	private int voltage;
	private String coolingCapacity;
	private String color;
	private String make;
	private int autoClimate;
	
	public aircon(String brand, int voltage, String coolingCapacity, 
					String color, String make, int autoClimate) {
		this.brand = brand;
		this.voltage = voltage;
		this.coolingCapacity = coolingCapacity;
		this.color = color;
		this.make = make;
		this.autoClimate = autoClimate;
	}
	
	public String getBrand() {
		return this.brand;
	}
	
	public int getVoltage() {
		return this.voltage;
	}
	
	public String getCoolingCapacity() {
		return this.coolingCapacity;
	}	
	
	public String getColor() {
		return this.color;
	}
	
	public String getMake() {
		return this.make;
	}
	
	public int getAutoClimate() {
		return this.autoClimate;
	}
	
}
