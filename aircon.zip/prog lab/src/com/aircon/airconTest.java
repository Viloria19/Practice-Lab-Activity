package com.aircon;

import com.aircon.aircon;

public class airconTest{

	public static void main(String[] args) {
		
		aircon a1 = new aircon("LG", 120, "7800 kJ/h", 
				"Piano Black", "LA080WC", 26);
		
		System.out.println("Aircon Specification: ");
		System.out.println("Brand :" + a1.getBrand());
		System.out.println("Voltage: " + a1.getVoltage());
		System.out.println("Cooling Capacity: " + a1.getCoolingCapacity());
		System.out.println("Color: " + a1.getColor());
		System.out.println("Make: " + a1.getMake());
		System.out.println("");
		System.out.println("Aircon will automatically set temperatures to " 
		+ a1.getAutoClimate());
	}
}
